PLEX DE MEDIA NOCHE 0.4.0 — KIT DE PRUEBA PARA KODI

Incluye el skin y las listas inteligentes de ejemplo para que los accesos de Estrenos puedan apuntar a listas locales de Kodi.

IMPORTANTE
- Esto NO es una APK Android.
- El skin deriva de una base experimental creada para Kodi; no es todavía una modificación completa de Arctic Zephyr Mod.
- No se ha probado en ejecución en un TV Box ni contra Kodi 22. Conserva el skin actual y no borres datos.
- Para que los accesos Estrenos funcionen, copia las listas del directorio userdata/playlists/video incluido en el ZIP principal a la carpeta de perfil de Kodi indicada en INSTALACION.txt.
- Cine y Series muestran las bibliotecas locales de Kodi. PlexKodiConnect debe estar conectado y haber terminado de sincronizar.
- TV requiere que el PVR/IPTV esté configurado en Kodi.
- Tráilers abre el navegador de complementos; instala y configura un complemento de tráiler compatible si quieres reproducirlos. Subtítulos abre Ajustes; configura un proveedor de subtítulos compatible.
